﻿using VertigoGamesCaseStudy.Runtime.ScriptableObjects;

namespace VertigoGamesCaseStudy.Runtime.Managers
{
	public interface IZoneSelector
	{
		ZoneBase GetCurrentZone(int currentZoneNumber);
	}
}