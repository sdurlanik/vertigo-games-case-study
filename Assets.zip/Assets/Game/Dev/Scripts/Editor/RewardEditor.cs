using System.Globalization;
using UnityEditor;
using UnityEngine;
using VertigoGamesCaseStudy.Runtime.ScriptableObjects;

namespace VertigoGamesCaseStudy.Editor
{
    [CustomEditor(typeof(RewardSO))]
    public class RewardEditor : UnityEditor.Editor
    {
        RewardSO _rewardSo;
        int _zoneNumber = 1; // Default zone number for debugging
        float _zoneRewardMultiplier = 1.03f; // Default zone reward multiplier for debugging

        void OnEnable()
        {
            _rewardSo = (RewardSO)target;
        }

        public override void OnInspectorGUI()
        {
            DrawIconSection();
            GUILayout.Space(20);

            DrawRewardProperties();
            GUILayout.Space(20);

            DrawDebuggingSection();
        }

        void DrawIconSection()
        {
            EditorGUILayout.LabelField("Reward Icon Display", EditorStyles.boldLabel);
            EditorGUILayout.BeginVertical("box");

            if (_rewardSo.icon != null)
            {
                DisplayIconWithAspectRatio();
            }
            else
            {
                EditorGUILayout.HelpBox("No Icon Assigned", MessageType.Warning);
            }

            EditorGUILayout.EndVertical();
        }

        void DisplayIconWithAspectRatio()
        {
            Texture2D sprite = AssetPreview.GetAssetPreview(_rewardSo.icon);
            if (sprite != null)
            {
                float aspectRatio = (float)sprite.width / sprite.height;
                float height = 100f;
                float width = height * aspectRatio;

                GUILayout.BeginHorizontal();
                GUILayout.FlexibleSpace();
                Rect rect = GUILayoutUtility.GetRect(width, height);
                GUI.DrawTexture(rect, sprite, ScaleMode.ScaleToFit);
                GUILayout.FlexibleSpace();
                GUILayout.EndHorizontal();
            }
        }

        void DrawRewardProperties()
        {
            EditorGUILayout.LabelField("Reward Properties", EditorStyles.boldLabel);
            EditorGUILayout.BeginVertical("box");
            base.OnInspectorGUI();
            EditorGUILayout.EndVertical();
        }

        void DrawDebuggingSection()
        {
            EditorGUILayout.LabelField("Debugging", EditorStyles.boldLabel);
            EditorGUILayout.BeginVertical("box");

            DrawZoneWeightCalculation();
            DrawZoneMultiplier();

            EditorGUILayout.EndVertical();
        }

        void DrawZoneWeightCalculation()
        {
            const string debugText = "Calculate the weight and value of the reward for a specific zone number. (Debugging purposes only)";
            EditorGUILayout.HelpBox(debugText, MessageType.Info);

            _zoneNumber = EditorGUILayout.IntField("Zone Number", _zoneNumber);
            EditorGUILayout.LabelField("Calculated Weight", _rewardSo.CalculateWeight(_zoneNumber).ToString("N1"));
        }

        void DrawZoneMultiplier()
        {
            GUILayout.Space(20);
            const string debugText = "Zone reward value multiplier can be changed in Zone ScriptableObjects. The default value is 1.03.";
            EditorGUILayout.HelpBox(debugText, MessageType.Info);

            _zoneRewardMultiplier = EditorGUILayout.FloatField("Zone Value Multiplier", _zoneRewardMultiplier);
            EditorGUILayout.LabelField("Calculated Value", (_rewardSo.baseAmount * _zoneRewardMultiplier * _zoneNumber).ToString("N0"));
        }
    }
}
