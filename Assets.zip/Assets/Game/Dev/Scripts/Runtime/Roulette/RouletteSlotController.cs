﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using VertigoGamesCaseStudy.Runtime.ScriptableObjects;
using VertigoGamesCaseStudy.Runtime.UI;

namespace VertigoGamesCaseStudy.Runtime
{
	public class RouletteSlotController
	{
		readonly Transform _slotsRoot;
		readonly RewardItem _rewardItemPrefab;
		readonly List<RewardItem> _rewardItems = new List<RewardItem>();

		public RouletteSlotController(Transform slotsRoot, RewardItem rewardItemPrefab)
		{
			_slotsRoot = slotsRoot;
			_rewardItemPrefab = rewardItemPrefab;
		}

		public IEnumerator InstantiateRewardItems(List<RewardSO> selectedRewards, float rewardMultiplier, int sliceCount)
		{
			for (int i = 0; i < selectedRewards.Count; i++)
			{
				var rewardSo = selectedRewards[i];
				var rewardItem = Object.Instantiate(_rewardItemPrefab, _slotsRoot);
				rewardItem.SetItem(rewardSo, i, rewardMultiplier, sliceCount);
				_rewardItems.Add(rewardItem);
				yield return new WaitForSeconds(0.05f);
			}
		}

		public void ResetSlots()
		{
			foreach (Transform child in _slotsRoot)
			{
				Object.Destroy(child.gameObject);
			}
			_rewardItems.Clear();
		}

		public RewardItem GetRewardItemByRewardSo(RewardSO selectedReward)
		{
			return _rewardItems.Find(item => item.Reward == selectedReward);
		}
	}
}