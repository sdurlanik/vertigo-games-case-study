using System;
using System.Collections;
using System.Collections.Generic;
using DG.Tweening;
using TMPro;
using UnityEngine;
using UnityEngine.UI;
using VertigoGamesCaseStudy.Runtime.ScriptableObjects;

namespace VertigoGamesCaseStudy.Runtime.UI
{
	public class RewardItem : MonoBehaviour
	{
		[SerializeField] TextMeshProUGUI amountText;
		[SerializeField] Image iconImage;

		[SerializeField] float scaleAnimationDuration = 0.3f;
		
		public int RewardAmount { get; set; } 
		public RewardSO Reward { get; set; }
		void OnEnable()
		{
			//scale up and down animation
			PlayScaleAnimation();
		}

		public void SetItem(RewardSO reward, int slotIndex,float rewardMultiplier, int sliceCount)
		{
			RewardAmount = Mathf.RoundToInt(reward.baseAmount * rewardMultiplier);
			Reward = reward;
			amountText.text = $"x{RewardAmount}";
				iconImage.sprite = reward.icon;
			
			SetRotationByIndex(sliceCount,slotIndex);
		}
		
		public void SetItem(RewardSO reward, int rewardAmount)
		{
			Reward = reward;
			RewardAmount = rewardAmount;
			iconImage.sprite = reward.icon;
			
			UpdateAmount();
		}

		public void OnRewardValueUpdated(int newValue)
		{
			RewardAmount += newValue;
			UpdateAmount();
			PlayScaleUpDownAnimation();
		}

		void UpdateAmount()
		{
			// Capture the current amount as the start value
			int currentAmount = int.Parse(amountText.text.Replace("x", ""));

			// Animate the amount from current value to the new RewardAmount using DoTween
			DOTween.To(() => currentAmount, x => currentAmount = x, RewardAmount, 0.5f) // 0.5f is the duration of the animation
				.OnUpdate(() =>
				{
					// Update the amount text during the tween
					amountText.text = $"x{currentAmount}";
				})
				.SetEase(Ease.OutCubic); // You can choose any easing function
		}

		
		void SetRotationByIndex(int sliceCount, int index)
		{
			RectTransform rectTransform = GetComponent<RectTransform>();
			
			float angle = 360f / sliceCount * index;
			Debug.Log( $"sliceCount {sliceCount}");
			Debug.Log( $"index {index}");
			Debug.Log($"Calculated angle: {angle}");
			rectTransform.localRotation = Quaternion.Euler(0, 0, angle);
		}
		
		void PlayScaleAnimation()
		{
			// Play scale-up animation and then scale-down back to normal
			RectTransform rectTransform = GetComponent<RectTransform>();
			rectTransform.localScale = Vector3.zero; // Start with zero scale

			// Scale up to max scale and then back down to normal (1, 1, 1)
			rectTransform.DOScale(Vector3.one, scaleAnimationDuration)
				.SetEase(Ease.OutBack);
		}
		
		void PlayScaleUpDownAnimation()
		{
			// Play scale-up animation and then scale-down back to normal
			RectTransform rectTransform = GetComponent<RectTransform>();
			rectTransform.localScale = Vector3.one; // Start with zero scale

			// Scale up to max scale and then back down to normal (1, 1, 1)
			rectTransform.DOScale(Vector3.one * 1.2f, scaleAnimationDuration)
				.SetEase(Ease.OutBack)
				.OnComplete(() => rectTransform.DOScale(Vector3.one, scaleAnimationDuration));
		}
	}
}
