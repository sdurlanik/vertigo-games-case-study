﻿using DG.Tweening;
using UnityEngine;

namespace VertigoGamesCaseStudy.Runtime
{
	public class SpinAnimator
	{
		readonly Transform _spinRoot;
		readonly float _spinDuration;
		readonly float _rotationAngle;
		readonly int _numberOfSpins;
		readonly int _sliceCount;

		public SpinAnimator(Transform spinRoot, float spinDuration, float rotationAngle, int numberOfSpins, int sliceCount)
		{
			_spinRoot = spinRoot;
			_spinDuration = spinDuration;
			_rotationAngle = rotationAngle;
			_numberOfSpins = numberOfSpins;
			_sliceCount = sliceCount;
		}

		public void SpinToIndex(int selectedIndex, TweenCallback onComplete)
		{
			float targetAngle = selectedIndex * (360f / _sliceCount);
			float totalRotation = _rotationAngle * _numberOfSpins + targetAngle;

			_spinRoot.DORotate(new Vector3(0, 0, -totalRotation), _spinDuration, RotateMode.FastBeyond360)
				.SetEase(Ease.OutCubic)
				.OnComplete(onComplete);
		}
	}
}