using System;
using UnityEngine;
using VertigoGamesCaseStudy.Core.Events;
using VertigoGamesCaseStudy.Runtime.UI;

public class ZoneSlideController : MonoBehaviour
    {
        [SerializeField] float switchDuration = 0.5f;
        
        [SerializeField] ZoneSlideItem currentZoneItem;
        [SerializeField] ZoneSlideBar zoneSlideBar;
        

        void OnEnable() => GameEventManager.Instance.On<StartNewZoneEvent>(OnNewZoneStarted);

        void OnDisable() => GameEventManager.Instance.Off<StartNewZoneEvent>(OnNewZoneStarted);
        
        void OnNewZoneStarted(StartNewZoneEvent e)
        {
            if(e.ZoneNumber == 1)
                return;
            
            currentZoneItem.UpdateCurrentZone(e.ZoneNumber, e.Zone.switchBarSprite, switchDuration);
            zoneSlideBar.SlideNumbers(e.ZoneNumber,switchDuration);
        }
    }