﻿using System.Collections.Generic;
using DG.Tweening;
using TMPro;
using UnityEngine;
using VertigoGamesCaseStudy;

namespace VertigoGamesCaseStudy.Runtime.UI
{
	public class ZoneSlideBar : MonoBehaviour
	{
		[SerializeField] RectTransform slideContent; // Content that holds the zone numbers (pivot of the content is on the left side of the first zone number)
		[SerializeField] TextMeshProUGUI zoneNumberPrefab;
		[SerializeField] int maxNumberCountInBar = 9;
		
		float _stepPixel = 0;
		readonly float _currentZoneBgWidth = 100;
		readonly List<TextMeshProUGUI> _zoneNumbers = new List<TextMeshProUGUI>();
		readonly IZoneColorProvider _zoneColorProvider = new ZoneColorProvider();

		int StartNumberCount => Mathf.CeilToInt((float) maxNumberCountInBar / 2);

		void Start()
		{
			CalculateContentStartPosition();
			CreateInitialNumbers();
		}

		void CalculateContentStartPosition()
		{
			float switchControllerWidth = GetComponent<RectTransform>().rect.width;
			_stepPixel = _currentZoneBgWidth;

			float slideContentStartPosition = switchControllerWidth / 2 - _currentZoneBgWidth / 2;
			slideContent.anchoredPosition = new Vector2(slideContentStartPosition, 0);
		}

		void CreateInitialNumbers()
		{
			for(int i = 0; i < StartNumberCount + 1; i++) // +1 extra number for the switch animation
			{
				AddZoneNumber(i + 1);
			}
		}

		public void SlideNumbers(int currentZoneNumber, float switchDuration)
		{
			slideContent.DOAnchorPosX(slideContent.anchoredPosition.x - _stepPixel, switchDuration)
				.SetEase(Ease.InOutSine)
				.OnComplete(() =>
				{
					RemoveOutOfSightNumbers();
					AddZoneNumber(currentZoneNumber + StartNumberCount);
				});
		}

		void RemoveOutOfSightNumbers()
		{
			if(_zoneNumbers.Count <= maxNumberCountInBar) return;

			var firstNumber = _zoneNumbers[0];
			_zoneNumbers.RemoveAt(0);
			Destroy(firstNumber.gameObject);

			// we removed the first number, so we need to move the content to the right because of the pivot position
			slideContent.anchoredPosition = new Vector2(slideContent.anchoredPosition.x + _stepPixel, 0);
		}
		
		void AddZoneNumber(int zoneNumber)
		{
			var zoneNumberInstance = Instantiate(zoneNumberPrefab, slideContent);
			zoneNumberInstance.text = $"{zoneNumber}";
			zoneNumberInstance.color = _zoneColorProvider.GetZoneNumberColor(zoneNumber);
			zoneNumberInstance.gameObject.name = $"ZoneNumber_{zoneNumber}";
			
			_zoneNumbers.Add(zoneNumberInstance);
		}
	}
}