﻿using VertigoGamesCaseStudy.Runtime.ScriptableObjects;

namespace VertigoGamesCaseStudy.Runtime.Managers
{
	public class ZoneSelector : IZoneSelector
	{
		readonly SuperZoneSO _superZoneSo;
		readonly SafeZoneSO _safeZoneSo;
		readonly DefaultZoneSO _defaultZoneSo;

		public ZoneSelector(SuperZoneSO superZoneSo, SafeZoneSO safeZoneSo, DefaultZoneSO defaultZoneSo)
		{
			_superZoneSo = superZoneSo;
			_safeZoneSo = safeZoneSo;
			_defaultZoneSo = defaultZoneSo;
		}

		public ZoneBase GetCurrentZone(int currentZoneNumber)
		{
			if (currentZoneNumber % _superZoneSo.triggerInterval == 0)
			{
				return _superZoneSo;
			}

			if (currentZoneNumber % _safeZoneSo.triggerInterval == 0)
			{
				return _safeZoneSo;
			}

			return _defaultZoneSo;
		}
	}
}