﻿using DG.Tweening;
using TMPro;
using UnityEngine;
using UnityEngine.UI;
using VertigoGamesCaseStudy;

namespace VertigoGamesCaseStudy.Runtime.UI
{
	public class ZoneSlideItem : MonoBehaviour
	{
		[SerializeField] Image currentZoneBgImage;
		[SerializeField] TextMeshProUGUI currentZoneNumberText;

		readonly IZoneColorProvider _zoneColorProvider = new ZoneColorProvider();

		public void UpdateCurrentZone(int zoneNumber, Sprite newZoneSwitchSprite, float switchDuration)
		{
			currentZoneBgImage.sprite = newZoneSwitchSprite;
			currentZoneNumberText.text = $"{zoneNumber}";
			currentZoneNumberText.color = _zoneColorProvider.GetZoneNumberColor(zoneNumber, true);

			AnimateZoneSwitch(switchDuration);
		}

		void AnimateZoneSwitch(float switchDuration)
		{
			currentZoneBgImage.DOFillAmount(1, switchDuration).From(0).SetEase(Ease.InOutSine);
			currentZoneNumberText.transform.DOScale(Vector3.one, switchDuration).From(Vector3.zero).SetEase(Ease.InOutSine);
		}
	}
}