using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using VertigoGamesCaseStudy.Core.Events;
using VertigoGamesCaseStudy.Runtime.ScriptableObjects;
using VertigoGamesCaseStudy.Runtime.UI;

namespace VertigoGamesCaseStudy
{
    public class RewardManager : MonoBehaviour
    {
        [SerializeField] RewardItem rewardItemPrefab;
        [SerializeField] RectTransform rewardItemRoot;

        readonly List<RewardItem> _rewardItemList = new List<RewardItem>();
        readonly Dictionary<RewardSO, RewardItem> _rewardItemDict = new Dictionary<RewardSO, RewardItem>();
        float _rewardItemHeight;

        void Awake() => _rewardItemHeight = rewardItemPrefab.GetComponent<RectTransform>().rect.height;

        void OnEnable() => GameEventManager.Instance.On<RewardPopupExitEvent>(OnRewardPopupExit);

        void OnDisable() => GameEventManager.Instance.Off<RewardPopupExitEvent>(OnRewardPopupExit);

        void OnRewardPopupExit(RewardPopupExitEvent e) => AddRewardItem(e.RewardItem);

        void AddRewardItem(RewardItem newReward)
        {
            if (newReward == null || newReward.Reward == null)
            {
                Debug.LogWarning("New reward or its RewardSO is null.");
                return;
            }

            if (_rewardItemDict.TryGetValue(newReward.Reward, out RewardItem existingRewardItem))
            {
                // Update the existing reward item's amount
                existingRewardItem.OnRewardValueUpdated(newReward.RewardAmount);
            }
            else
            {
                RewardItem rewardItemInstance = Instantiate(rewardItemPrefab, rewardItemRoot);
                rewardItemInstance.SetItem(newReward.Reward, newReward.RewardAmount);
                _rewardItemDict.Add(newReward.Reward, rewardItemInstance);
                _rewardItemList.Add(rewardItemInstance);
            }
        }

        public Vector3 GetNextRewardItemPosition(RewardItem newReward)
        {
            if(newReward == null || newReward.Reward == null)
            {
                Debug.LogWarning("New reward or its RewardSO is null.");
                return Vector3.zero;
            }

            if(_rewardItemDict.TryGetValue(newReward.Reward, out RewardItem existingRewardItem))
            {
                return existingRewardItem.transform.position;
            }

            if(_rewardItemList.Count == 0)
            {
                float topPositionY = rewardItemRoot.position.y + rewardItemRoot.rect.height / 2;
                float newY = topPositionY - _rewardItemHeight / 2;
                return new Vector3(rewardItemRoot.position.x, newY, rewardItemRoot.position.z);
            }
            else
            {
                RewardItem lastRewardItem = _rewardItemList.Last();
                float newY = lastRewardItem.transform.position.y - _rewardItemHeight;
                return new Vector3(lastRewardItem.transform.position.x, newY, lastRewardItem.transform.position.z);
            }

        }
    }
}
