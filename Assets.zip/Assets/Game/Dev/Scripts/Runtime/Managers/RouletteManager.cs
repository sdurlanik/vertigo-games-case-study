using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using VertigoGamesCaseStudy.Core.Events;
using VertigoGamesCaseStudy.Runtime.Managers;
using VertigoGamesCaseStudy.Runtime.ScriptableObjects;
using VertigoGamesCaseStudy.Runtime.UI;

namespace VertigoGamesCaseStudy.Runtime
{
    public class RouletteManager : MonoBehaviour
    {
        [SerializeField] Image rouletteBaseImage, rouletteIndicatorImage;
        [SerializeField] Button spinButton;
        [SerializeField] Transform spinRoot, slotsRoot;
        [SerializeField] float spinDuration = 3f;
        [SerializeField] float rotationAngle = 360f;
        [SerializeField] int numberOfSpins = 5;
        [SerializeField] RewardItem rewardItemPrefab;

        public PopupController popupController;

        const int SLICE_COUNT = 8;
        
        float _currentRewardMultiplier = 1f;
        int _currentZoneNumber = 1;
        List<RewardSO> _selectedRewards = new List<RewardSO>();


        IRewardSelector _rewardSelector;
        ZoneBase _currentZone;
        SpinAnimator _spinAnimator;
        RouletteSlotController _rouletteSlotController;

        void Awake()
        {
            _rewardSelector = new RewardSelector();
            _spinAnimator = new SpinAnimator(spinRoot, spinDuration, rotationAngle, numberOfSpins, SLICE_COUNT);
            _rouletteSlotController = new RouletteSlotController(slotsRoot, rewardItemPrefab);
        }

        void Start()
        {
            spinButton.interactable = false;
            
        }

        void OnValidate()
        {
            if(spinButton == null)
            {
                spinButton = GetComponentInChildren<Button>();
            }
        }

        void OnEnable()
        {
            GameEventManager.Instance.On<StartNewZoneEvent>(SetRoulette);
            spinButton.onClick.AddListener(SpinRoulette);
        }

        void OnDisable()
        {
            GameEventManager.Instance.Off<StartNewZoneEvent>(SetRoulette);
            spinButton.onClick.RemoveListener(SpinRoulette);
        }
        void SetRoulette(StartNewZoneEvent startNewZoneEvent)
        {
            _currentZone = startNewZoneEvent.Zone;
            _currentZoneNumber = startNewZoneEvent.ZoneNumber;
            _currentRewardMultiplier = _currentZone.rewardValueMultiplier * startNewZoneEvent.ZoneNumber;
            
            rouletteBaseImage.sprite = _currentZone.rouletteBaseSprite;
            rouletteIndicatorImage.sprite = _currentZone.rouletteIndicatorSprite;
            spinButton.interactable = false;

            ResetSlots();
            SetSlots(_currentZone.rewards);
        }

        void SpinRoulette()
        {
            spinButton.interactable = false;

            RewardSO selectedReward = _rewardSelector.SelectReward(_selectedRewards, _currentZoneNumber);
            int selectedIndex = _selectedRewards.IndexOf(selectedReward);

            _spinAnimator.SpinToIndex(selectedIndex, () => OnSpinComplete(selectedReward));
        }

        void OnSpinComplete(RewardSO selectedReward)
        {
            Debug.Log("Selected Reward: " + selectedReward.name);

            var rewardItem = _rouletteSlotController.GetRewardItemByRewardSo(selectedReward);
            popupController.ShowRewardPopup(rewardItem, _currentRewardMultiplier);
        }
        void SetSlots(List<RewardSO> rewards)
        {
            _selectedRewards = _rewardSelector.SelectRewards(rewards, SLICE_COUNT, _currentZoneNumber);
            StartCoroutine(InstantiateRewardItemsCoroutine());
        }

        IEnumerator InstantiateRewardItemsCoroutine()
        {
            yield return StartCoroutine(_rouletteSlotController.InstantiateRewardItems(_selectedRewards, _currentRewardMultiplier, SLICE_COUNT));
            spinButton.interactable = true;
        }

        void ResetSlots()
        {
            _currentRewardMultiplier = 1f;
            _selectedRewards.Clear();
            _rouletteSlotController.ResetSlots();
        }
    }
}