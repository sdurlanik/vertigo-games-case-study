using System;
using UnityEngine;
using VertigoGamesCaseStudy.Core.Events;
using VertigoGamesCaseStudy.Runtime.ScriptableObjects;

namespace VertigoGamesCaseStudy.Runtime.Managers
{
	public class ZoneManager : MonoBehaviour
	{
		[Header("Zone Data")]
		[SerializeField] SuperZoneSO superZoneSo;
		[SerializeField] SafeZoneSO safeZoneSo;
		[SerializeField] DefaultZoneSO defaultZoneSo;
		
		int _currentZoneNumber = 0;
		IZoneSelector _zoneSelector;

		void Awake() => _zoneSelector = new ZoneSelector(superZoneSo, safeZoneSo, defaultZoneSo);
		
		void Start() => StartNewZone();
		
		void OnEnable() => GameEventManager.Instance.On<RewardPopupExitEvent>(OnRewardPopupExit);

		void OnDisable() => GameEventManager.Instance.Off<RewardPopupExitEvent>(OnRewardPopupExit);
		
		void OnRewardPopupExit(RewardPopupExitEvent e) => StartNewZone();
		
		void StartNewZone()
		{
			_currentZoneNumber++;
			
			var currentZone = _zoneSelector.GetCurrentZone(_currentZoneNumber);
			
			var startNewZoneEvent = new StartNewZoneEvent
			{
				ZoneNumber = _currentZoneNumber,
				Zone = currentZone
			};
			
			GameEventManager.Instance.Fire(startNewZoneEvent);
		}
	}
}
