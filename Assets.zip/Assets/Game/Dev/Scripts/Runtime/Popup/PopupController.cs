using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using VertigoGamesCaseStudy.Runtime.ScriptableObjects;
using VertigoGamesCaseStudy.Runtime.UI;

namespace VertigoGamesCaseStudy.Runtime
{
    public class PopupController : MonoBehaviour
    {
        [SerializeField] RewardPopup rewardPopup;
        
        public void ShowRewardPopup(RewardItem rewardItem, float rewardMultiplier)
        {
            rewardPopup.SetReward(rewardItem, rewardMultiplier);
            rewardPopup.gameObject.SetActive(true);
        }
        
    }
}
