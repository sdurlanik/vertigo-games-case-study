﻿using DG.Tweening;
using UnityEngine;
using UnityEngine.UI;

namespace VertigoGamesCaseStudy.Runtime.UI
{
	using DG.Tweening;
	using UnityEngine;

	public class PopupAnimator
	{
		public static void PlayScaleAnimation(Transform target, Vector3 from, Vector3 to, float duration, Ease ease, TweenCallback onComplete = null)
		{
			target.DOScale(to, duration)
				.From(from)
				.SetEase(ease)
				.OnComplete(onComplete);
		}

		public static void PlayMoveAnimation(Transform target, Vector3 to, float duration, Ease ease, TweenCallback onComplete = null)
		{
			target.DOLocalMove(to, duration)
				.SetEase(ease)
				.OnComplete(onComplete);
		}
		
		public static void PlayRotationAnimation(Transform target, Vector3 rotation, float duration, RotateMode mode, TweenCallback onComplete = null)
		{
			target.DORotate(rotation, duration, mode)
				.SetEase(Ease.OutCubic)
				.OnComplete(onComplete);
		}

		public static void PlayCloneAnimation(Image clone, Vector3 randomOffset, RectTransform targetTransform, float expandDuration, float moveDuration, Ease moveEase, TweenCallback onComplete = null)
		{
			PlayScaleAnimation(clone.transform, Vector3.zero, Vector3.one * 0.5f, expandDuration, Ease.OutBack);

			PlayMoveAnimation(clone.transform, clone.transform.localPosition + (Vector3.up * 100) + randomOffset, expandDuration, Ease.OutBack);
			
			PlayMoveAnimation(clone.transform, targetTransform.position, moveDuration, moveEase, onComplete);
		}

		public static void PlayExitAnimation(Transform target, Vector3 targetPosition, float duration, TweenCallback onComplete = null)
		{
			PlayMoveAnimation(target, targetPosition, duration, Ease.OutBack, onComplete);
			PlayScaleAnimation(target, Vector3.one, Vector3.zero, duration, Ease.OutBack);
		}
	}

}