using System.Collections;
using System.Collections.Generic;
using DG.Tweening;
using TMPro;
using UnityEngine;
using UnityEngine.UI;
using VertigoGamesCaseStudy.Core.Events;
using VertigoGamesCaseStudy.Runtime.ScriptableObjects;

namespace VertigoGamesCaseStudy.Runtime.UI
{
    public class RewardPopup : PopupBase
    {
        [SerializeField] Image rewardImage;
        [SerializeField] TextMeshProUGUI rewardNameText, rewardAmountText;
        [SerializeField] int cloneCount = 5;
        [SerializeField] float expandDuration = 0.5f;
        [SerializeField] float moveDuration = 0.7f;
        [SerializeField] RewardManager rewardManager;
        
        readonly Vector3 _initialScale = Vector3.zero;
        readonly Vector3 _targetScale = Vector3.one;
        const float ROTATION_AMOUNT = 360f;

        RewardItem _rewardItem;
        
        public void SetReward(RewardItem rewardItem, float rewardMultiplier)
        {
            ResetValues();

            _rewardItem = rewardItem;
            rewardImage.sprite = rewardItem.Reward.icon;
            rewardNameText.text = rewardItem.Reward.displayName;
            rewardAmountText.text = $"x{Mathf.RoundToInt(rewardItem.Reward.baseAmount * rewardMultiplier)}";
        }

        protected override void Enter()
        {
            base.Enter();
            Debug.Log("RewardPopup Enter");
            PlayEnterAnimation();
        }

        void ResetValues()
        {
            transform.localPosition = Vector3.zero;
            transform.localScale = _initialScale;
            _clones.Clear();
            _rewardItem = null;
        }

        void PlayEnterAnimation()
        {
            AnimateScale(_targetScale, expandDuration, Ease.OutBack);
            AnimateRotation(ROTATION_AMOUNT, expandDuration, Ease.OutCubic, StartRewardAnimation);
        }

        void AnimateScale(Vector3 scaleTarget, float duration, Ease easeType)
        {
            transform.DOScale(scaleTarget, duration).SetEase(easeType);
        }

        void AnimateRotation(float angle, float duration, Ease easeType, TweenCallback onComplete)
        {
            transform.DORotate(new Vector3(0, 0, angle), duration, RotateMode.FastBeyond360)
                .SetEase(easeType)
                .OnComplete(onComplete);
        }

        List<Image> _clones = new List<Image>(); // Store the clones for simultaneous movement

        private void StartRewardAnimation()
        {
            for(int i = 0; i < cloneCount; i++)
            {
                StartCoroutine(CreateCloneAndExpand(i));
            }
        }

        IEnumerator CreateCloneAndExpand(int index)
        {
            yield return new WaitForSeconds(index * 0.1f); // Delay between clone creation
            Image clone = CreateCloneImage();
            _clones.Add(clone); // Add clone to list for later movement

            PlayCloneExpandAnimation(clone);

            // After all clones have finished expanding, move them all simultaneously
            if(index == cloneCount - 1)
            {
                yield return new WaitForSeconds(expandDuration); // Wait for the last clone's expand animation to complete
                MoveAllClonesToTarget();
            }
        }

        void PlayCloneExpandAnimation(Image clone)
        {
            // Apply a random offset for clone expansion to avoid overlap
            Vector3 randomOffset = Random.insideUnitCircle * 100f; // Create a random offset for expansion
            Vector3 expandedPosition = clone.transform.localPosition + Vector3.up * 100 + randomOffset;

            // Expand the clone with offset and scaling
            clone.transform.DOScale(Vector3.one * 0.5f, expandDuration)
                .SetEase(Ease.OutBack);

            // Animate the clone to expand outward to the random offset position
            clone.transform.DOLocalMove(expandedPosition, expandDuration)
                .SetEase(Ease.OutBack);
        }

        void MoveAllClonesToTarget()
        {
            foreach(Image clone in _clones)
            {
                // Move all clones to the target simultaneously
                clone.transform.DOMove(rewardManager.GetNextRewardItemPosition(_rewardItem), moveDuration)
                    .SetEase(Ease.InBack)
                    .OnComplete(() =>
                    {
                        // Destroy each clone after reaching the target
                        Destroy(clone.gameObject);
                    });
            }

            // After all clones move, trigger the exit
            DOVirtual.DelayedCall(moveDuration, Exit);
        }
        Image CreateCloneImage()
        {
            Image clone = Instantiate(rewardImage, rewardImage.transform.position, Quaternion.identity, transform);
            clone.transform.localScale = _initialScale;
            return clone;
        }
        protected override void Exit()
        {
            base.Exit();
            Debug.Log("RewardPopup Exit");
            PlayExitAnimation();
            FireRewardPopupExitEvent();
        }

        void PlayExitAnimation()
        {
            Vector3 targetPosition = new Vector3(0, -Screen.height, 0);
            float duration = 1f;

            transform.DOLocalMove(targetPosition, duration).SetEase(Ease.OutBack)
                .OnComplete(() =>
                {
                    gameObject.SetActive(false);
                });
            AnimateScale(_initialScale, duration, Ease.OutBack);
        }

        void FireRewardPopupExitEvent()
        {
            var rewardPopupExitEvent = new RewardPopupExitEvent { RewardItem = _rewardItem };
            GameEventManager.Instance.Fire(rewardPopupExitEvent);
        }

    }
}
