﻿using UnityEngine;

namespace VertigoGamesCaseStudy.Runtime.ScriptableObjects
{
	[CreateAssetMenu (fileName = "DefaultZone", menuName = "VertigoGamesCaseStudy/DefaultZone")]
	public class DefaultZoneSO : ZoneBase
	{

	}
}