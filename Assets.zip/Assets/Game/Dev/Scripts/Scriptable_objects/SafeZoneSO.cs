﻿using System.Collections.Generic;
using UnityEngine;

namespace VertigoGamesCaseStudy.Runtime.ScriptableObjects
{
	[CreateAssetMenu (fileName = "SafeZone", menuName = "VertigoGamesCaseStudy/SafeZone")]
	public class SafeZoneSO : ZoneBase
	{
		
	}
}