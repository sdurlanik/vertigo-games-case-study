﻿using VertigoGamesCaseStudy.Runtime.ScriptableObjects;
using VertigoGamesCaseStudy.Runtime.UI;

namespace VertigoGamesCaseStudy.Core.Events
{
	public abstract class GameEvent
	{
		public int Priority { get; set; }
	}
	
	public class StartNewZoneEvent : GameEvent
	{
		public int ZoneNumber { get; set; }
		public ZoneBase Zone { get; set; }
	}
	
	public class RewardPopupExitEvent : GameEvent
	{
		public RewardItem RewardItem { get; set; }
	}
}